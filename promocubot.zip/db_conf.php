<?php 
// servidor, usuario, contrasenia
/*usuario= cmclmcom_webmast ---- contrasenia=CLMwebmaster123*/
/*BD = cmclmcom_testedu*/
$user = "root"; //"ramslexc_webmast";
$password = "";//"RXwebmaster123";
$server = "localhost";
$dbname = "reservascubot";
?>