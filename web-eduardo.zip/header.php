<?php
echo '<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>'.$title.'Promoción Smartphone Cubot</title>

	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap-timepicker.css">
	<link rel="stylesheet" type="text/css" href="css/datepicker.css">
	<link rel="stylesheet" type="text/css" href="css/validationEngine.jquery.css">
	<link rel="stylesheet" type="text/css" href="css/styles.css">

	<link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300" rel="stylesheet" type="text/css">
</head>
<body>';
?>